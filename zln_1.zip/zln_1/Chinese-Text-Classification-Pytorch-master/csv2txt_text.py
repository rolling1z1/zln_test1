import pandas as pd
import os
import glob


#train
cvs_path = r'dev.csv'
# txt_train_path = 'train'
# txt_test_path = 'test'

label = ["A10", "AG600", "B1", "B2", "B52", "Be200", "C130", "C17", "C5", "E2", "EF2000", "F117", "F14", "F15", "F16",
         "F18", "F22", "F35", "F4", "J20", "JAS39", "Mi310", "MQ29", "Mirage", "RQ4", "Rafale", "SR71", "A12", "Su57",
         "Tu160", "Tu95", "Tu142", "U2", "US2", "V22", "XB70", "YF23", "MQ9", "Mig31", "Mirage2000"]

fileNamePath = cvs_path[:-4]
out_txt_path = os.path.join(fileNamePath + '.txt')  # 保存到csv的目录

df = pd.read_csv('dev.csv')
print("1")
the_class = df.iloc[0]['label']
the_title = df.iloc[0]['title']

out_file = open(out_txt_path, 'w', encoding='UTF-8')  # 以追加写入的写入的方式打开TXT
#out_file.write(str(the_cls) + ' ' + ' '.join([str(round(a, 6)) for a in box]) + '\n')  # 把内容写入TXT中

print(the_class)