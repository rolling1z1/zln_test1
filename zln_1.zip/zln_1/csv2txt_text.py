import pandas as pd
import os
import glob


#train
cvs_path = r'dev.csv'
# txt_train_path = 'train'
# txt_test_path = 'test'

label = ["A10", "AG600", "B1", "B2", "B52", "Be200", "C130", "C17", "C5", "E2", "EF2000", "F117", "F14", "F15", "F16",
         "F18", "F22", "F35", "F4", "J20", "JAS39", "Mi310", "MQ29", "Mirage", "RQ4", "Rafale", "SR71", "A12", "Su57",
         "Tu160", "Tu95", "Tu142", "U2", "US2", "V22", "XB70", "YF23", "MQ9", "Mig31", "Mirage2000"]

fileNamePath = cvs_path[:-4]
out_txt_path = os.path.join(fileNamePath + '.txt')  # 保存到csv的目录

df = pd.read_csv('filename.csv')

print("all")
print(df)
print(df.shape)
print(df.shape[0])
out_file = open(out_txt_path, 'w', encoding='UTF-8')  # 以写入的方式打开TXT
for i in range(0,df.shape[0]):
    the_title = df.iloc[i]['title']
    the_class = df.iloc[i]['label']
    out_file.write(str(the_title) + "\t" + str(the_class) + '\n')  # 把内容写入TXT中

