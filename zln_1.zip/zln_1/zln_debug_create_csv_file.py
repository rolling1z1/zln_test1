
import pandas as pd

# 创建一个三行四列的DataFrame
df = pd.DataFrame({
    'title': ['苹果', '雪梨', '香蕉'],
    'desc': ['苹果的描述', '雪梨的描述', '香蕉的描述'],
    'text': ['苹果的文本', '雪梨的文本', '香蕉的文本'],
    'label': ['苹果1', '雪梨1', '香蕉1']
})

# 将DataFrame存储为CSV文件
df.to_csv('filename.csv', index=False)

# 输出DataFrame
print(df)